# GitHub release preparation

Prepared tag: **v2.5.0**. Title: **Matrix Rain 2.5.0**. Windows/UEM version: **2.5.0.0**.

1. Target https://github.com/bdgarmon/MatrixRain (default branch main). Verified empty with no releases on 2026-09-23.
2. Add the contents of repository/ to the repository root, preserving any existing repository license and project policies. Review source licensing before publication; no license has been selected or invented in this bundle.
3. Commit the source/documentation and create a draft release tagged v2.5.0 at that commit. Do not overwrite an existing v2.5.0 tag/release without reviewing it.
4. Paste RELEASE-NOTES.md into the release description.
5. Attach every file in assets/, including the UEM guide, detection script, icon, source archive and SHA256SUMS.txt. Upload the inner UEM ZIP to Workspace ONE; the outer GitHub handoff ZIP is not a UEM package.
6. Review and publish when ready. This preparation did not push code, create a repository or publish a release.

The package/ directory is staging material for the deployable ZIP and does not need to be committed. repository/ excludes binaries and machine logs. Runtime/source/configuration bytes are identical to the tested 2.5.0.0 build. Public docs are revised and the deployable ZIP has new checksums accordingly.
